<?php
 /**
 *
 *
 *
 *
 */
session_start();

require_once "autoloader.php";

//use db\DbcClass as DbcClass;
//use register\RegisterClass as RegisterClass;


//trying to connect to data base
try {

    $db = new db\DbcClass("localhost", "testDataBase", "root", "123");
  
} catch (Exception $e) {

    echo $e->getMessage();

}

//Getting registration date
$registerDate = date("d-m-Y G:i:s");

//Getting IP of user
$userIP = $_SERVER['REMOTE_ADDR'];

//Creating array key for insert to db
$IParr = array("userIP" => "{$userIP}");

//Creating array key for insert to db
$regDateArr = array("userRegisterDate" => "{$registerDate}");

/* insert to db array */
$arr = array(
    "userLogin"          => "yffdffyo",
    "userFirstName"      => "fdyfsdfds",
    "userLastName"       => "Ljjjjj",
    "userEmail"          => "aa34@xample.com",
    "userPhoneNumber"    => "057272222",
    "userPassword"       => "123456",
    "userRepeatPassword" => "123456"




    );

/* adding to array new array keys */
$arr = array_merge($arr, $regDateArr, $IParr);

/* Inserting user data to DB */
$register = $db->registerNewUser($arr, true)->runSQL();

if ($sta) {

    $register->mailTo('viktorlubchuk@gmail.com', "Registration on Landing Magic Project");
    echo "user was inserted successful";
} else {

    if (isset($_SESSION['errorLogin'])) {
        echo $_SESSION['errorLogin']."<br>";
        unset($_SESSION['errorLogin']);
    }

    if (isset($_SESSION['errorEmail'])) {
        echo $_SESSION['errorEmail']."<br>";
        unset($_SESSION['errorEmail']);
    }

   
    echo "Error with user data ! check the data";
}
